#!/bin/sh
nohup ./DoomBFA &