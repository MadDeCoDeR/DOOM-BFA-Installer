#!/bin/sh
nohup ./DoomBFA +set fs_game_base DOOM2 -classich &