#!/bin/sh
nohup ./DoomBFA +set fs_game_base UDOOM -classich &